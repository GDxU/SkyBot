﻿using System;

namespace NadekoBot.Modules.Administration.Common.Migration
{
    public class MigrationException : Exception
    {

    }
}
